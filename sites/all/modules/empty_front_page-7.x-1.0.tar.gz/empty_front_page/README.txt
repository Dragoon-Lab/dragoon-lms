Empty Front Page
----------------

This is an ultra lightweight module that remove default content from 
the frontpage.


Installation
------------
Place empty_front_page in the modules directory for your site and enable it.

Make sure your 'Default front page' setting is empty. 
See admin/config/system/site-information.
